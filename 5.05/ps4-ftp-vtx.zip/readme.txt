FTP server for PS4, with self dumping support

ftpps4 v1.3
